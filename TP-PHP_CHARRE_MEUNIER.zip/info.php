<!--<pre>


    <?php
echo "<br>";
if(session_status()==PHP_SESSION_ACTIVE) {
    echo "session opened with params :";
}
else
    echo "session closed";

echo "<br>";
print_r($_SESSION);
print_r($_POST);

?>

</pre> -->