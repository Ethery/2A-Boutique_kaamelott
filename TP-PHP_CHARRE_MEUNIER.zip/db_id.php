<?php
$user = 'ethery';
$pass = 'ethery';
$dsn = 'mysql:host=localhost;
    dbname=boutique_kaamelott';
?>
